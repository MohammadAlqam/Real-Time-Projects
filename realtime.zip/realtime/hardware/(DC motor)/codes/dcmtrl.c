#include <pic.h>
#include "delay.h"

__CONFIG(DEBUG_OFF & WDTE_OFF & LVP_OFF & FOSC_HS & BOREN_ON);

void DelaySec(int sec); /* a function to delay in terms of seconds */

void main(void)
{
	/* 	RB5 controls enabling/disabling the motor 
		RB6 and RB7 are used to control the direction of rotation */
	
	TRISB = 0;
	RB5=1; /* Eabling the Motor A */ 
	while (1) {
		RB7 = 1; /* Rotate Clockwise */
		RB6 = 0;
		DelaySec(2);
		RB7 = 0; /* Rotate Counter-Clockwise */
		RB6 = 1;
		DelaySec(2);
	 }
}

void DelaySec(int sec)
{
   for(int i=0;i<sec;i++)
    DelayMs(1000);
}
