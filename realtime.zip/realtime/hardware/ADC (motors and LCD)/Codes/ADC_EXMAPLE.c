#include <stdlib.h>
#include <stdio.h>
#include <pic.h>
#include "lcd.h"
#include "delay.h"
#include "string.h"
/*
*	since we're using 4MHz oscillator, we need to set the oscillator bit to HS
*	the following are needed to make the LCD get to work:
*	BODEN, WDTDIS and WRTEN
*/

__CONFIG(DEBUG_OFF & WDTE_OFF & LVP_OFF & FOSC_HS & BOREN_ON);

unsigned int  rising_edge_time_1=0; // hold the current value of rising edge time 
unsigned int  period = 0; // hold the current value of rising edge time 
char str[10] ;
int isFirstEdge = 1;

void DelaySec(int sec);
void init_a2d(void); 
float read_a2d(unsigned char channel);
float x;//to hold analog value
float y;//to hold analog value
float k;//to hold analog value
char str[10]; 

void main(void){ 
	ADCON1 = 7; // Set A/D-pins as digital I/O
	nRBPU = 0;   // enable internal pullups on PORTB
	TRISE = 0;  // set port E in output mode
	TRISD = 0;  // set port D in output mode
	RE2 = 0;    // Initialize PortE pin 2 

	GIE = 1;  // Global Interrupt Enable 
	PEIE = 1;

	//Timer1 configuration 
	TMR1CS = 0; //(this is one bit in T1CON) use internal clock  (Fosc/4) , where Fosc= 4MHz in our case
	TMR1IF = 0; // set Timer interrupt flag bit to 0. It is set to 1 when an overflow is occurred in Timer1 
	TMR1H  = 0x00;  //(The Initial value) the MSB 8 bit for Timer1 , which has the value of the timer
	TMR1L = 0x00; // (The Initial value)the LSB 8 bit for Timer1. 
	T1CKPS0 = 0;  T1CKPS1 = 0;  //set the prescale value to 1:1 (See datasheet) 
	T1SYNC = 0;// Timer is synchronized to external clock input
	TMR1IE = 1;// enable TIMER1 interrupt 
	TMR1ON = 1; //Enable Timer1

	//Configure CCP module to Capture mode
	CCP1M3 = 0; CCP1M2 = 1; CCP1M1 = 0; CCP1M0 = 1;  // Capture mode,   every rising edge
	CCP1IE = 1; // enable CCP1 interrupt
	CCP1IF = 0; 





	unsigned char rec;
	TRISC = 0 ;	// set PORTC as output
	PORTC = 0 ; // clear PORTC 
	TRISD = 0; /* to transmit characters to the LCD */
	TRISE = 0; /* to control the LCD */
	TRISB = 0; /* to control the motor */
	ADCON1 = 3;//set PORT A to Digital mode, Port E to digital 
	TRISA = 0xFF; /* to take analog values */  
	TRISC7=1;  /* set RC7 to input (RX) to receive bits */
	TRISC6=0;  /* set RC6 to output (TX) ro send bits */
	DelaySec(1); //sleep for 1 sec
	
	/* Loading screen */
	lcd_init(); /* Initialize the LCD */
	lcd_clear(); /* in case of a reset */
	lcd_puts("Starting...");
	DelayMs(1000);

	nRBPU = 0; /* enable pullup resistors */ 
	
	
	init_a2d();  /* Initialize the A2D module */
	DelayMs(500);
	
	lcd_clear();
	GIE=0;  /* Disable global interrupts */
	while ( 1 ) { 
	
		DelayMs(100); /* increase to 100 in case any problems occured during the implementation */
		 

		/* Read analog value on AN0, adjust by coeficient to obtain actual value */
		x= read_a2d(0);
		x = x/70.0; /* fraction to reflect actual analog value (since it reaches within the range of the analog register */
		y= read_a2d(1);
		y = y/70.0;
		
		lcd_goto(0);
		ftoa(x, str, 2); /* Convert value to string with 2 digits after the point */
		lcd_puts(str); /* display value on LCD */

		lcd_goto(64);
		ftoa(y, str, 2); /* Convert value to string with 2 digits after the point */
		lcd_puts(str); /* display value on LCD */
		

		k = x * y ;
		
		lcd_goto(70);
		ftoa(k, str, 2); /* Convert value to string with 2 digits after the point */
		lcd_puts(str); /* display value on LCD */
		
		
		if(k>5.4){
		
	
		PR2 = 82 ; //set PR2 Regesiter to  66 decimal ( PR2 = (fosc)/(4*f*prescaler) - 1 ) to configure the frequency
		T2CON =   0b00000100; //set Timer2 control Register , where Prescaler is 1 and Postscale is 1:1
		CCP1CON = 0b00101100; //set CCP1 to Pulse Width Modulation Mode. 0b00(10)(1100) , (least signficat two bits in duty cycle) , (pwm mode)
	
		//the output will be generated from RC2(CCP1)
		for(;;){
		/* PWM resolution is 10 bits, so only CCPRxL have to be touched to change duty cycle */
		/* set CCPR1L to 25 to give 50% duty cycle with frequency = 15 KHz , note that DC1B1 and DC1B0 are set to 10 in CCP1CON */
		// CCPR1L(7..0):CPP1Con(5):CPP1Con(5) =   (fosc *on_time_percentage)/(F * prescaler) = (4MHz*0.5)/(15K * 1)
		// = 133 = ?0010000101? as 10bits => CCPR1L will get most 8 significant bits 00100001 and CCP1CON<5:4> = 01
		CCPR1L = 0b00101001 ;    
	}

	
		
		
		
		}

/*
		if(x > 2.0){
			 lcd_clear(); 
			 lcd_puts("bigger 2.0");
			 DelayMs(1000);
			 RB1 = 1;//turn on motor
		}
		else {
			lcd_puts("less than 2.0");
			DelayMs(100);
		    RB1 = 0;

		}
	*/
	}

}


void init_a2d(void){ 
	ADCON0 = 0x41; // (01)(000)(0)0(1) = ( select Fosc/8) , (AN0), (GO_DONE), (enable)
	ADCON1 = 0x0E; //(0)(0)00(1110) (select left justify result), (select Fosc/8)   ,(AN0 is analog wiht Vdd and Vss) 
	ADON=1; // turn on the A2D conversion module (last bit in ADCON0)
}
	
/* Return an 8 bit result */ 
float read_a2d(unsigned char channel){ 
	channel &=0x07; // truncate channel to 3 bits 
	ADCON0 = 0x41; // select Fosc/8 
	ADCON1 = 0x0E; //  select left justify result, A/D port configuration 0 
	DelayMs(10);	
	ADCON0 |=(channel<<3); // apply the new channel select
	GO_nDONE = 1;
	while(GO_nDONE)
		continue; 
	return( (float) ADRESH); // return 8 MSB of the result
	}

void DelaySec(int sec)
{
   for(int i=0;i<sec;i++)
    DelayMs(1000);
}


static void interrupt ISR(void) {
	//CCP1IF
  // check if the interrupt is 1 
  if ( CCP1IF ) {
	//store the time of rising or falling edge in  rising_edge_time by getting the time value from CCPR1L   
	if( (int) CCPR1%1000000==0){
		
		RC0=1;
	}

	RC1=0;
	isFirstEdge = !isFirstEdge;
	//rest the CCP1 interrupt flag to 0
    CCP1IF = 0;
  }

  //check if the Timer1 is overflowed 
  if ( TMR1IF ) {
	//rest the Timer1 counter to 0
    TMR1H = 0x00;  TMR1L = 0x00;
	//reset Timer1 overflow flag to 0
    TMR1IF = 0;
  }
}