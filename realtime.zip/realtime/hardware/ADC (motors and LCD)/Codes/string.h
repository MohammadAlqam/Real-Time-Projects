#include <pic.h>
extern void reverse(char *str, int len);
extern int intToStr(int x, char str[], int d);
extern void ftoa(float n, char *res, int afterpoint);