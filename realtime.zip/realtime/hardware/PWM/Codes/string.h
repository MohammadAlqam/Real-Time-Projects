#include <pic.h>
extern void reverse(char *str, int len);
extern unsigned int intToStr(unsigned int x, char str[], int d);
extern void ftoa(float n, char *res, int afterpoint);